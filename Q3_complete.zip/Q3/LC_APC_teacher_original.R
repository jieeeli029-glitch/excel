############################################################
# Lee-Carter and Renshaw-Haberman models
# Australian male mortality, 1921-2016
############################################################

# Install these once if needed:
# install.packages("StMoMo")
# install.packages("reshape2")
# install.packages("forecast")

library(StMoMo)
library(reshape2)
library(forecast)

############################################################
# 1. Read deaths and exposures
############################################################

deaths_raw <- read.table(
  "Deaths_1x1.txt",
  header = TRUE,
  stringsAsFactors = FALSE
)

exposures_raw <- read.table(
  "Exposures_1x1.txt",
  header = TRUE,
  stringsAsFactors = FALSE
)

# Check column names
names(deaths_raw)
names(exposures_raw)

############################################################
# 2. Clean age variable
############################################################

# The final age may be recorded as "110+"
clean_age <- function(age) {
  as.numeric(gsub("\\+", "", age))
}

deaths_raw$Age_num <- clean_age(deaths_raw$Age)
exposures_raw$Age_num <- clean_age(exposures_raw$Age)

############################################################
# 3. Select years, ages and male data
############################################################

years.fit <- 1981:2021

# You can change this if you want to exclude very young or very old ages.
# For the full lecture-note range, use ages 0 to 110.
ages.fit <- 20:89

deaths <- subset(
  deaths_raw,
  Year %in% years.fit & Age_num %in% ages.fit
)

exposures <- subset(
  exposures_raw,
  Year %in% years.fit & Age_num %in% ages.fit
)

############################################################
# 4. Create deaths and exposure matrices
############################################################
# Rows = ages
# Columns = years

Dxt <- acast(
  deaths,
  Age_num ~ Year,
  value.var = "Male"
)

Ext <- acast(
  exposures,
  Age_num ~ Year,
  value.var = "Male"
)

# Make sure rows and columns are ordered correctly
Dxt <- Dxt[as.character(ages.fit), as.character(years.fit)]
Ext <- Ext[as.character(ages.fit), as.character(years.fit)]

# Convert to matrices
Dxt <- as.matrix(Dxt)
Ext <- as.matrix(Ext)

# Check dimensions
dim(Dxt)
dim(Ext)

############################################################
# 5. Basic data checks
############################################################

# Central death rates
mxt <- Dxt / Ext

# Check for zeros, missing values or infinite log rates
sum(is.na(Dxt))
sum(is.na(Ext))
sum(Ext <= 0, na.rm = TRUE)
sum(Dxt < 0, na.rm = TRUE)
sum(!is.finite(log(mxt)), na.rm = TRUE)

# For StMoMo, exposures should be positive.
# If some very high ages have zero exposure, exclude them.
valid_ages <- ages.fit[rowSums(Ext <= 0 | is.na(Ext)) == 0]

valid_ages
length(valid_ages)

Dxt <- Dxt[as.character(valid_ages), ]
Ext <- Ext[as.character(valid_ages), ]

ages.fit <- valid_ages


############################################################
# 6. Fit Lee-Carter model
############################################################

LC <- lc(link = "log")

LC.fit <- fit(
  LC,
  Dxt = Dxt,
  Ext = Ext,
  ages = ages.fit,
  years = years.fit
)

summary(LC.fit)

############################################################
# 7. Extract Lee-Carter parameters
############################################################

ax.LC <- LC.fit$ax
bx.LC <- LC.fit$bx[, 1]
kt.LC <- LC.fit$kt[1, ]

# Put parameters into data frames
LC.ax <- data.frame(
  age = ages.fit,
  ax = ax.LC
)

LC.bx <- data.frame(
  age = ages.fit,
  bx = bx.LC
)

LC.kt <- data.frame(
  year = years.fit,
  kt = as.numeric(kt.LC)
)

head(LC.ax)
head(LC.bx)
head(LC.kt)

############################################################
# 8. Plot Lee-Carter fitted parameters
############################################################

plot(
  LC.ax$age, LC.ax$ax,
  type = "l",
  xlab = "Age x",
  ylab = expression(a[x]),
  main = "Lee-Carter: age effect"
)

plot(
  LC.bx$age, LC.bx$bx,
  type = "l",
  xlab = "Age x",
  ylab = expression(b[x]),
  main = "Lee-Carter: age sensitivity"
)

plot(
  LC.kt$year, LC.kt$kt,
  type = "l",
  xlab = "Year t",
  ylab = expression(k[t]),
  main = "Lee-Carter: period effect"
)

############################################################
# 9. Forecast Lee-Carter model
############################################################

LC.forecast <- forecast(
  LC.fit,
  h = 50
)

plot(LC.forecast)

# Forecasted central death rates
LC.rates.forecast <- fitted(LC.forecast, type = "rates")

# Example: forecast age 50 mortality
LC.age50 <- LC.rates.forecast["50", ]

head(LC.age50)
tail(LC.age50)

############################################################
# 10. Fit Renshaw-Haberman model
############################################################
# The RH model includes a cohort term.
# cohortAgeFun = "NP" gives an age-modulated cohort effect,
# corresponding to c_x h_{t-x}.

RH <- rh(
  link = "log",
  cohortAgeFun = "NP",
  approxConst = TRUE
)

RH.fit <- fit(
  RH,
  Dxt = Dxt,
  Ext = Ext,
  ages = ages.fit,
  years = years.fit
)

summary(RH.fit)

############################################################
# 11. Extract Renshaw-Haberman parameters
############################################################

ax.RH <- RH.fit$ax

# Period age sensitivity b_x
bx.RH <- RH.fit$bx[, 1]

# Period factor k_t
kt.RH <- RH.fit$kt[1, ]

# Cohort age sensitivity c_x
cx.RH <- RH.fit$b0x

# Cohort factor h_c
hc.RH <- RH.fit$gc

# Cohort years
cohorts.RH <- as.numeric(names(hc.RH))

RH.ax <- data.frame(
  age = ages.fit,
  ax = ax.RH
)

RH.bx <- data.frame(
  age = ages.fit,
  bx = bx.RH
)

RH.kt <- data.frame(
  year = years.fit,
  kt = as.numeric(kt.RH)
)

RH.cx <- data.frame(
  age = ages.fit,
  cx = cx.RH
)

RH.hc <- data.frame(
  cohort = cohorts.RH,
  hc = as.numeric(hc.RH)
)

head(RH.ax)
head(RH.bx)
head(RH.kt)
head(RH.cx)
head(RH.hc)

############################################################
# 12. Plot Renshaw-Haberman fitted parameters
############################################################

plot(
  RH.ax$age, RH.ax$ax,
  type = "l",
  xlab = "Age x",
  ylab = expression(a[x]),
  main = "Renshaw-Haberman: age effect"
)

plot(
  RH.bx$age, RH.bx$bx,
  type = "l",
  xlab = "Age x",
  ylab = expression(b[x]),
  main = "Renshaw-Haberman: period age sensitivity"
)

plot(
  RH.kt$year, RH.kt$kt,
  type = "l",
  xlab = "Year t",
  ylab = expression(k[t]),
  main = "Renshaw-Haberman: period effect"
)

plot(
  RH.cx$age, RH.cx$cx,
  type = "l",
  xlab = "Age x",
  ylab = expression(c[x]),
  main = "Renshaw-Haberman: cohort age sensitivity"
)

plot(
  RH.hc$cohort, RH.hc$hc,
  type = "l",
  xlab = "Cohort c = t - x",
  ylab = expression(h[c]),
  main = "Renshaw-Haberman: cohort effect"
)

############################################################
# 13. Forecast Renshaw-Haberman model
############################################################

RH.forecast <- forecast(
  RH.fit,
  h = 50
)

plot(RH.forecast)

RH.rates.forecast <- fitted(RH.forecast, type = "rates")

# Example: forecast age 50 mortality
RH.age50 <- RH.rates.forecast["50", ]

head(RH.age50)
tail(RH.age50)

############################################################
# 14. Compare Lee-Carter and Renshaw-Haberman age-50 forecasts
############################################################

comparison.age50 <- data.frame(
  year = as.numeric(colnames(LC.rates.forecast)),
  LC = as.numeric(LC.rates.forecast["50", ]),
  RH = as.numeric(RH.rates.forecast["50", ])
)

head(comparison.age50)
tail(comparison.age50)

plot(
  comparison.age50$year,
  comparison.age50$LC,
  type = "l",
  xlab = "Year",
  ylab = expression(hat(m)[50 * "," * t]),
  main = "Forecast age-50 male central mortality rate"
)

lines(
  comparison.age50$year,
  comparison.age50$RH,
  lty = 2
)

legend(
  "topright",
  legend = c("Lee-Carter", "Renshaw-Haberman"),
  lty = c(1, 2),
  bty = "n"
)


#######
############################################################
# Side-by-side LC and RH estimated parameter plots
############################################################

# Extract LC parameters
LC.ax <- data.frame(
  age = ages.fit,
  ax = LC.fit$ax
)

LC.bx <- data.frame(
  age = ages.fit,
  bx = LC.fit$bx[, 1]
)

LC.kt <- data.frame(
  year = years.fit,
  kt = as.numeric(LC.fit$kt[1, ])
)

# Extract RH parameters
RH.ax <- data.frame(
  age = ages.fit,
  ax = RH.simple.fit$ax
)

RH.bx <- data.frame(
  age = ages.fit,
  bx = RH.simple.fit$bx[, 1]
)

RH.kt <- data.frame(
  year = years.fit,
  kt = as.numeric(RH.simple.fit$kt[1, ])
)

RH.hc <- data.frame(
  cohort = as.numeric(names(RH.simple.fit$gc)),
  hc = as.numeric(RH.simple.fit$gc)
)

############################################################
# Put LC and RH side by side: ax, bx, kt
############################################################

pdf(
  file = "LC_RH_plot1.pdf",
  width = 7,
  height = 4.5
)

par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))

plot(
  LC.ax$age, LC.ax$ax,
  type = "l",
  xlab = "Age x",
  ylab = expression(a[x]),
  main = "Lee-Carter: age effect"
)

plot(
  RH.ax$age, RH.ax$ax,
  type = "l",
  xlab = "Age x",
  ylab = expression(a[x]),
  main = "Renshaw-Haberman: age effect"
)

plot(
  LC.bx$age, LC.bx$bx,
  type = "l",
  xlab = "Age x",
  ylab = expression(b[x]),
  main = "Lee-Carter: age sensitivity"
)

plot(
  RH.bx$age, RH.bx$bx,
  type = "l",
  xlab = "Age x",
  ylab = expression(b[x]),
  main = "Renshaw-Haberman: period age sensitivity"
)


dev.off()



pdf(
  file = "LC_RH_plot2.pdf",
  width = 7,
  height = 4.5
)
par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))

plot(
  LC.kt$year, LC.kt$kt,
  type = "l",
  xlab = "Year t",
  ylab = expression(k[t]),
  main = "Lee-Carter: period effect"
)

plot(
  RH.kt$year, RH.kt$kt,
  type = "l",
  xlab = "Year t",
  ylab = expression(k[t]),
  main = "Renshaw-Haberman: period effect"
)
plot(
  RH.cx$age, RH.cx$cx,
  type = "l",
  xlab = "Age x",
  ylab = expression(c[x]),
  main = "Renshaw-Haberman: cohort age sensitivity"
)

plot(
  RH.hc$cohort, RH.hc$hc,
  type = "l",
  xlab = "Cohort c = t - x",
  ylab = expression(h[c]),
  main = "Renshaw-Haberman: cohort effect"
)
dev.off()
