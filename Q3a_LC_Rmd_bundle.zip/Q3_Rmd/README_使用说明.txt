Q3a_LC_analysis.Rmd — 同时包含 Q3(a) 与 Q3(b)

1. 解压整个 ZIP；保留以下结构，不要只移动 Rmd：
   Q3_Rmd/
     Q3a_LC_analysis.Rmd
     Q3a_LC_analysis.html
     data/
       AUS_Deaths_1x1.txt
       AUS_Exposures_1x1.txt
       UK_Deaths_1x1.txt
       UK_Exposures_1x1.txt

2. 在 RStudio Console 安装所需包（只需首次安装）：
   install.packages(c("StMoMo", "reshape2", "rmarkdown", "knitr", "fields"))

3. 在 RStudio 选择 File > Open File，打开 Q3a_LC_analysis.Rmd。
4. 点击 Knit（或 Knit to HTML）。不要使用 file.choose()。
5. 不必设置桌面绝对路径。RStudio 默认在 Rmd 所在文件夹中 Knit，程序从旁边的 data 文件夹读取数据。
   如将数据另放他处，修改 Rmd 顶部 params 中 data_dir 的值。
6. 双击已附带的 Q3a_LC_analysis.html，可先查看实际运行的结果；其中图表嵌入文件。

已核对内容：
- 文件头确认澳大利亚/英国及死亡数/暴露量的对应关系；四份原始文件都是第3行为表头。
- 从 Total 读取，1961–2005年、40–90岁，矩阵年龄为行、年份为列。
- 不读取之前保存的拟合结果，不用示例男性数据，不把英国指向澳大利亚文件。
- LC/RH 均使用老师 LC_APC.R 的 StMoMo 方法；无额外预测。
- 去掉教师脚本的 forecast 部分、age50 对比及未定义 RH.simple.fit 引用。
- 主残差图有数值色标；配合符号图比较 cohort 斜线，避免只按国家大小或总deviance作判断。
- Q3(b) 使用实际残差的描述性队列符号一致性汇总确定比较国家，不在拟合代码中预先固定为UK。
  该汇总不是正式检验、不是新的拟合目标；图像仍是主要证据。
- 本文件已在 R 4.5.0、StMoMo 0.4.1 环境真实 Knit 为 HTML，完成全部代码块。
- 首次 Knit 含 RH 拟合，可能需要等待；请看 RStudio Render/Knit 面板进度。

GitHub raw 链接如果在浏览器中显示源代码，可用“另存为”，保留 .Rmd 后缀。
